import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

export async function generateEducationalTherapyResponse(
  message: string,
  conversationHistory: { role: "user" | "assistant"; content: string }[]
): Promise<string> {
  try {
    const systemPrompt = `You are EduMind AI, an educational therapy assistant designed to help students manage academic stress, improve study techniques, and maintain mental wellness in educational contexts.

Guidelines:
- Focus only on educational and academic topics
- Provide supportive, empathetic responses
- Offer practical advice for academic challenges
- Suggest evidence-based study techniques
- Help with time management and organization
- Provide stress-reduction strategies for students
- Maintain a positive, encouraging tone
- If asked about non-educational topics, gently redirect to educational focus

Important: You are not a substitute for professional mental health services. For severe mental health concerns, suggest speaking to a mental health professional.`;

    // Combine history with the new message
    const messages = [
      { role: "system", content: systemPrompt },
      ...conversationHistory,
      { role: "user", content: message }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: messages as any,
      temperature: 0.7,
      max_tokens: 500,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Error generating response:", error);
    return "I'm having trouble connecting to my knowledge base. Please try again in a moment.";
  }
}
