import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize Google's Generative AI with the API key
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export async function generateEducationalTherapyResponse(
  message: string,
  conversationHistory: { role: "user" | "assistant"; content: string }[]
): Promise<string> {
  try {
    // Create a combined prompt that includes system instructions and the user's message
    const systemPrompt = `You are StudyRelief AI, an educational therapy assistant designed to help students manage academic stress, improve study techniques, and maintain mental wellness in educational contexts.

Guidelines:
- Focus only on educational and academic topics
- Provide supportive, empathetic responses
- Offer practical advice for academic challenges
- Suggest evidence-based study techniques
- Help with time management and organization
- Provide stress-reduction strategies for students
- Maintain a positive, encouraging tone
- If asked about non-educational topics, gently redirect to educational focus
- Keep responses concise (max 3-4 paragraphs)

Important: You are not a substitute for professional mental health services. For severe mental health concerns, suggest speaking to a mental health professional.

Recent conversation history:
${conversationHistory.map(msg => `${msg.role === "user" ? "User" : "StudyRelief"}: ${msg.content}`).join('\n')}

User's current message: ${message}

Your response as StudyRelief:`;

    // Set up the model
    // The available Gemini models are listed at: https://ai.google.dev/models/gemini
    const model = genAI.getGenerativeModel({ 
      model: "gemini-pro",  // Standard model name
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 500,
      },
    });

    // Generate response with the combined prompt
    const result = await model.generateContent(systemPrompt);
    const response = result.response;
    return response.text() || "I'm sorry, I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Error generating response:", error);
    console.error("API Key present:", !!process.env.GEMINI_API_KEY);
    console.error("API Key length:", process.env.GEMINI_API_KEY ? process.env.GEMINI_API_KEY.length : 0);
    return "I'm having trouble connecting to my knowledge base. Please try again in a moment.";
  }
}