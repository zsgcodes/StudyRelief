import { 
  messages, conversations, users,
  type Message, type InsertMessage,
  type User, type InsertUser,
  type Conversation, type InsertConversation
} from "@shared/schema";
import { db } from "./db";
import { v4 as uuidv4 } from "uuid";
import { eq, and, desc } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getMessages(conversationId: string): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.createdAt);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    // Check if the conversation exists
    const [existingConversation] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, insertMessage.conversationId));
    
    // If not, create it
    if (!existingConversation) {
      await db
        .insert(conversations)
        .values({
          id: insertMessage.conversationId,
          updatedAt: new Date(),
        });
    } else {
      // Update the conversation's updatedAt timestamp
      await db
        .update(conversations)
        .set({ updatedAt: new Date() })
        .where(eq(conversations.id, insertMessage.conversationId));
    }
    
    // Add the message
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    
    return message;
  }

  async clearConversation(conversationId: string): Promise<void> {
    await db
      .delete(messages)
      .where(eq(messages.conversationId, conversationId));
    
    // Update the conversation's timestamps
    await db
      .update(conversations)
      .set({ 
        updatedAt: new Date(),
        createdAt: new Date()
      })
      .where(eq(conversations.id, conversationId));
  }

  generateConversationId(): string {
    return uuidv4();
  }
}