import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateEducationalTherapyResponse, welcomeMessage } from "./local-ai";
import { chatInputSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint to get messages for a conversation
  app.get("/api/messages/:conversationId", async (req, res) => {
    try {
      const { conversationId } = req.params;
      const messages = await storage.getMessages(conversationId);
      
      return res.json({ messages });
    } catch (error) {
      console.error("Error fetching messages:", error);
      return res.status(500).json({ 
        message: "Failed to fetch messages" 
      });
    }
  });

  // API endpoint to create a new conversation ID
  app.post("/api/conversation", async (req, res) => {
    try {
      const conversationId = storage.generateConversationId();
      
      // Add an initial message from the assistant
      await storage.createMessage({
        content: welcomeMessage,
        isUser: false,
        conversationId
      });
      
      return res.json({ conversationId });
    } catch (error) {
      console.error("Error creating conversation:", error);
      return res.status(500).json({ 
        message: "Failed to create a new conversation" 
      });
    }
  });

  // API endpoint to send a message and get a response
  app.post("/api/chat", async (req, res) => {
    try {
      // Validate the request body
      const { message, conversationId } = chatInputSchema.parse(req.body);
      
      // If no conversationId is provided, create a new one
      const activeConversationId = conversationId || storage.generateConversationId();
      
      // Save the user message
      await storage.createMessage({
        content: message,
        isUser: true,
        conversationId: activeConversationId
      });
      
      // Get conversation history for context
      const conversationHistory = await storage.getMessages(activeConversationId);
      
      // Format conversation history for OpenAI
      const formattedHistory = conversationHistory.map(msg => ({
        role: msg.isUser ? "user" : "assistant" as "user" | "assistant",
        content: msg.content
      }));
      
      // Generate AI response
      const aiResponse = await generateEducationalTherapyResponse(
        message, 
        formattedHistory
      );
      
      // Save the AI response
      const savedResponse = await storage.createMessage({
        content: aiResponse,
        isUser: false,
        conversationId: activeConversationId
      });
      
      return res.json({ 
        message: savedResponse,
        conversationId: activeConversationId
      });
    } catch (error) {
      console.error("Error processing chat:", error);
      
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: validationError.message 
        });
      }
      
      return res.status(500).json({ 
        message: "Failed to process your message" 
      });
    }
  });

  // API endpoint to clear conversation history
  app.delete("/api/conversation/:conversationId", async (req, res) => {
    try {
      const { conversationId } = req.params;
      await storage.clearConversation(conversationId);
      
      // Add the initial message back
      await storage.createMessage({
        content: welcomeMessage,
        isUser: false,
        conversationId
      });
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error clearing conversation:", error);
      return res.status(500).json({ 
        message: "Failed to clear conversation" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
