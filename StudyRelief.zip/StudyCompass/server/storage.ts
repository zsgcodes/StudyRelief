import { type Message, type InsertMessage, type User, type InsertUser } from "@shared/schema";
import { DatabaseStorage } from "./database-storage";

// Interface for storage operations
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Message methods
  getMessages(conversationId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  clearConversation(conversationId: string): Promise<void>;
  generateConversationId(): string;
}

// Export an instance of DatabaseStorage as our storage implementation
export const storage: IStorage = new DatabaseStorage();
