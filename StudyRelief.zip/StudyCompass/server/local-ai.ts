/**
 * A simple local response generator for educational therapy questions
 * This doesn't require any external API calls and serves as a fallback
 * when API keys for AI services aren't available or working
 */

type MessageHistory = { role: "user" | "assistant"; content: string }[];

// Set of predefined responses for common educational therapy questions
// Includes conversational and personalized responses for user engagement
const responses = [
  // Personalized educational therapy responses from CSV
  {
    keywords: ["overwhelmed", "assignments", "too many tasks"],
    response: "It's okay to feel overwhelmed. Let's break down your tasks into manageable steps. What's one assignment you can start on today for just 15 minutes?"
  },
  {
    keywords: ["can't focus", "distracted while studying"],
    response: "Try the Pomodoro technique: 25 minutes of focus followed by a 5-minute break. Would you like me to guide you through one cycle?"
  },
  {
    keywords: ["scared of failing", "afraid of exam", "worried about test"],
    response: "It's natural to feel anxious before a test. Let's try a calming breathing exercise together first, then review what you already know to boost your confidence."
  },
  {
    keywords: ["blank out", "mind goes blank", "freeze during test"],
    response: "Test anxiety can freeze your brain. Try writing down a few key concepts right before the test begins. Want to practice a grounding technique now?"
  },
  {
    keywords: ["don't feel like studying", "lost motivation", "can't study anymore"],
    response: "Burnout is real, and rest is productive too. Let's first acknowledge how you're feeling. Want to set one small goal today to regain momentum?"
  },
  {
    keywords: ["why try", "what's the point", "feels pointless"],
    response: "When everything feels heavy, it's hard to see purpose. But your effort matters. Let's explore what you're passionate about and reconnect with your 'why.'"
  },
  {
    keywords: ["feeling sad", "feeling down", "depressed", "tired lately"],
    response: "You're not alone — many students feel this way. It might help to talk more about it. Would you like to try a guided reflection or calming visualization?"
  },
  {
    keywords: ["feel anxious", "anxiety", "anxious for no reason"],
    response: "Let's do a quick grounding exercise together. Focus on 5 things you can see, 4 you can touch, 3 you can hear... Ready?"
  },
  {
    keywords: ["stress relief", "quick technique", "calming technique"],
    response: "Sure! Try box breathing: inhale for 4 seconds, hold for 4, exhale for 4, hold again for 4. Repeat this 4 times. Want me to guide you?"
  },
  {
    keywords: ["need help calming", "calm down", "feeling stressed right now"],
    response: "Take a deep breath. I'm here for you. Let's slow things down with a short mindfulness exercise. Ready to begin?"
  },
  {
    keywords: ["not good enough", "inadequate", "feeling worthless"],
    response: "That's a hard feeling. But your worth isn't defined by grades or productivity. Want to try a self-kindness affirmation exercise together?"
  },
  {
    keywords: ["everyone else is better", "others doing better", "falling behind"],
    response: "Comparison steals joy. You're on your own path, and that's okay. Let's set one realistic goal today just for *you*."
  },
  
  // Original detailed educational therapy responses
  {
    keywords: ["exam stress", "test anxiety", "nervous about exam", "anxious about test"],
    response: `Exam stress is something many students experience. Try these techniques:

1. **Preparation**: Create a study schedule and break down material into manageable chunks.

2. **Relaxation techniques**: Practice deep breathing, progressive muscle relaxation, or mindfulness meditation before studying and before the exam.

3. **Positive self-talk**: Replace thoughts like "I can't do this" with "I've prepared well and will do my best."

4. **Physical care**: Ensure you're getting enough sleep, eating well, and exercising regularly leading up to the exam.

5. **Visualization**: Imagine yourself calmly taking the exam and recalling information successfully.`
  },
  {
    keywords: ["procrastination", "can't focus", "distracted", "putting off", "postponing"],
    response: `Procrastination is a common challenge. Here are some strategies to overcome it:

1. **Break tasks down**: Divide large assignments into smaller, manageable steps.

2. **Pomodoro Technique**: Work for 25 minutes, then take a 5-minute break. After 4 cycles, take a longer break.

3. **Remove distractions**: Put your phone away or use apps that block distracting websites while you work.

4. **Set specific goals**: Instead of "study biology," try "read and take notes on chapter 3 for 45 minutes."

5. **Reward yourself**: Plan small rewards for completing tasks.`
  },
  {
    keywords: ["time management", "schedule", "planning", "organize time"],
    response: `Effective time management is crucial for academic success. Consider these approaches:

1. **Use a planner**: Digital or paper planners help visualize your commitments and deadlines.

2. **Prioritize tasks**: Use the Eisenhower Matrix to categorize tasks by urgency and importance.

3. **Set realistic goals**: Be honest about how long tasks actually take you.

4. **Create routines**: Regular study schedules help build productive habits.

5. **Buffer time**: Always add extra time between tasks to account for unexpected delays.`
  },
  {
    keywords: ["study techniques", "study methods", "learn better", "remember information", "memorize"],
    response: `Effective study techniques can significantly improve learning. Try these evidence-based methods:

1. **Spaced repetition**: Review material at increasing intervals rather than cramming.

2. **Active recall**: Quiz yourself instead of simply re-reading notes.

3. **Concept mapping**: Create visual connections between ideas and concepts.

4. **Teaching others**: Explaining concepts in your own words enhances understanding.

5. **Varied study environments**: Occasionally changing where you study can improve retention.`
  },
  {
    keywords: ["motivation", "unmotivated", "don't feel like", "can't get started"],
    response: `Finding motivation for studies can be challenging. Here are some strategies:

1. **Connect to purpose**: Remind yourself why this education matters to your long-term goals.

2. **Start small**: Commit to just 5-10 minutes of work to overcome initial resistance.

3. **Find your peak time**: Identify when you naturally have more energy and focus.

4. **Accountability partner**: Study with a friend or share goals with someone who will check in on progress.

5. **Change your environment**: Sometimes a new study location can provide fresh perspective and energy.`
  },
  {
    keywords: ["group project", "team assignment", "collaborate", "working with others"],
    response: `Group projects require different skills than individual work. Here's how to navigate them effectively:

1. **Clear communication**: Establish preferred communication channels and response timeframes early.

2. **Define roles**: Assign specific responsibilities based on each person's strengths.

3. **Set deadlines**: Create internal deadlines before the final due date to allow review time.

4. **Regular check-ins**: Schedule brief meetings to ensure everyone is on track.

5. **Conflict resolution**: Address issues promptly and focus on solutions rather than blame.`
  },
  {
    keywords: ["concentration", "focus", "pay attention", "mind wandering"],
    response: `Improving concentration takes practice. These techniques can help:

1. **Environment optimization**: Create a dedicated study space free from distractions.

2. **Task blocking**: Group similar tasks together to reduce mental switching costs.

3. **Mindfulness practice**: Regular meditation can improve attention span over time.

4. **Physical movement**: Short bursts of exercise can refresh focus when attention wanes.

5. **Brain-friendly nutrition**: Stay hydrated and opt for foods that support cognitive function.`
  },
  {
    keywords: ["overwhelmed", "too much", "stressed", "burnout", "exhausted"],
    response: `Feeling overwhelmed with academic demands is common. Here's how to manage:

1. **Audit commitments**: List all your responsibilities and identify what can be reduced or eliminated.

2. **Chunk large projects**: Break overwhelming tasks into smaller, more manageable pieces.

3. **Set boundaries**: Practice saying no to additional commitments when necessary.

4. **Self-care**: Ensure you're meeting basic needs for sleep, nutrition, and relaxation.

5. **Seek support**: Talk to academic advisors, counseling services, or trusted mentors about adjusting your workload.`
  },
  {
    keywords: ["note taking", "notes", "lecture notes", "class notes"],
    response: `Effective note-taking enhances learning and retention. Consider these methods:

1. **Cornell Method**: Divide your page into sections for notes, key questions, and summary.

2. **Mind Mapping**: Create visual notes with branches showing relationships between concepts.

3. **Outline Method**: Organize information hierarchically with main points and supporting details.

4. **Active listening**: Focus on capturing main ideas rather than writing everything verbatim.

5. **Review strategy**: Schedule time to review and consolidate notes within 24 hours of the lecture.`
  },
  {
    keywords: ["sleep", "tired", "insomnia", "rest", "nap"],
    response: `Sleep is crucial for learning and academic performance. Consider these strategies:

1. **Consistent schedule**: Try to sleep and wake at similar times daily, even on weekends.

2. **Pre-sleep routine**: Develop calming activities before bed like reading or gentle stretching.

3. **Screen management**: Reduce exposure to blue light from devices at least 1 hour before bed.

4. **Study timing**: Avoid intensive studying right before bedtime.

5. **Strategic napping**: A 20-minute nap can boost alertness without affecting nighttime sleep.`
  },
];

// Default response when no pattern matches
const defaultResponse = "I understand you're looking for help with your studies or academic life. Could you provide more details about what specific challenge you're facing with your learning, time management, or academic stress? I'm here to offer strategies tailored to your situation.";

// Welcome message for new conversations
export const welcomeMessage = "Hi there! I'm StudyRelief, your educational therapy assistant. How can I help with your studies or academic stress today?";

/**
 * Generate a response based on pattern matching with predefined responses
 */
export async function generateEducationalTherapyResponse(
  message: string,
  conversationHistory: MessageHistory
): Promise<string> {
  try {
    const lowercaseMessage = message.toLowerCase();
    
    // Analyze conversation history to provide more contextual responses
    const isFollowUp = conversationHistory.length > 1;
    const lastBotMessage = isFollowUp ? 
      conversationHistory.filter(msg => msg.role === "assistant").pop()?.content : 
      null;
    
    // Handle follow-up responses more naturally
    if (isFollowUp && 
        (lowercaseMessage.includes("yes") || 
         lowercaseMessage.includes("sure") || 
         lowercaseMessage.includes("okay") || 
         lowercaseMessage.includes("alright"))) {
      
      // If the last bot message asked about stress relief techniques
      if (lastBotMessage && 
          (lastBotMessage.includes("breathing exercise") || 
           lastBotMessage.includes("guide you") || 
           lastBotMessage.includes("Ready?") || 
           lastBotMessage.includes("Ready to begin?"))) {
        
        return "Great! Let's do this together:\n\n1. Sit comfortably and close your eyes if possible.\n\n2. Take a slow, deep breath in through your nose for 4 seconds.\n\n3. Hold that breath for 4 seconds.\n\n4. Exhale slowly through your mouth for 6 seconds.\n\n5. Repeat this 3-4 times.\n\nHow do you feel now? Remember, this simple technique can be used anytime you're feeling stressed or anxious.";
      }
      
      // If the last bot message mentioned goal setting
      if (lastBotMessage && lastBotMessage.includes("goal")) {
        return "Excellent! Let's start small: think of one 15-minute task you can complete today related to your studies. It could be reviewing notes, organizing your study space, or even just writing down questions you have about a topic. Once you complete it, take a moment to acknowledge your progress - every step forward matters!";
      }
    }
    
    // Check for gratitude expressions
    if (lowercaseMessage.includes("thank") || 
        lowercaseMessage.includes("thanks") || 
        lowercaseMessage.includes("helpful")) {
      return "You're welcome! I'm glad I could help. Remember that managing academic stress is an ongoing process. Be patient with yourself, celebrate small victories, and don't hesitate to reach out again if you need more support!";
    }
    
    // Look for matching keywords in our predefined responses
    for (const item of responses) {
      if (item.keywords.some(keyword => lowercaseMessage.includes(keyword))) {
        return item.response;
      }
    }
    
    // If no matches, look for common question patterns
    if (lowercaseMessage.includes("how do i") || 
        lowercaseMessage.includes("what is") || 
        lowercaseMessage.includes("can you help") ||
        lowercaseMessage.includes("tips for")) {
      return "I'd be happy to help with that. Could you provide more specific details about your question? For example, if you're asking about study techniques, let me know what subject you're studying or what specific challenges you're facing.";
    }
    
    // Handle greetings
    if (lowercaseMessage.includes("hello") || 
        lowercaseMessage.includes("hi") || 
        lowercaseMessage.includes("hey") || 
        lowercaseMessage.includes("greetings")) {
      return "Hello! I'm here to help with your academic questions and concerns. How are you feeling about your studies today?";
    }
    
    // If no patterns matched, return the default response
    return defaultResponse;
    
  } catch (error) {
    console.error("Error generating local response:", error);
    return "I apologize, but I'm having trouble processing your request right now. Could you try asking your question again?";
  }
}