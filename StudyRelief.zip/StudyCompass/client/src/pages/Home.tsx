import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Message, type ChatResponse, type ConversationResponse, type MessagesResponse } from "@/lib/types";
import Header from "@/components/Header";
import WelcomeMessage from "@/components/WelcomeMessage";
import ChatContainer from "@/components/ChatContainer";
import ChatInput from "@/components/ChatInput";
import SuggestedQuestions from "@/components/SuggestedQuestions";

const SUGGESTED_QUESTIONS = [
  "How can I focus better while studying?",
  "Tips for test anxiety?",
  "How to balance school and self-care?",
  "Strategies for effective note-taking?",
  "Ways to stay motivated during long study sessions?"
];

export default function Home() {
  const [conversationId, setConversationId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  // Create a new conversation
  const createConversation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/conversation", {});
      return response.json() as Promise<ConversationResponse>;
    },
    onSuccess: (data) => {
      setConversationId(data.conversationId);
      queryClient.invalidateQueries({ queryKey: [`/api/messages/${data.conversationId}`] });
    }
  });

  // Get messages for the current conversation
  const { data: messagesData, isLoading: isLoadingMessages } = useQuery<MessagesResponse>({
    queryKey: conversationId ? [`/api/messages/${conversationId}`] : [],
    enabled: !!conversationId,
  });

  // Send a message and get a response
  const sendMessage = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/chat", { 
        message, 
        conversationId 
      });
      return response.json() as Promise<ChatResponse>;
    },
    onSuccess: (data) => {
      setConversationId(data.conversationId);
      queryClient.invalidateQueries({ queryKey: [`/api/messages/${data.conversationId}`] });
    }
  });

  // Clear conversation history
  const clearConversation = useMutation({
    mutationFn: async () => {
      if (!conversationId) return;
      const response = await apiRequest("DELETE", `/api/conversation/${conversationId}`, {});
      return response.json();
    },
    onSuccess: () => {
      if (conversationId) {
        queryClient.invalidateQueries({ queryKey: [`/api/messages/${conversationId}`] });
      }
    }
  });

  // Create a new conversation when the component mounts
  useEffect(() => {
    createConversation.mutate();
  }, []);

  const handleSendMessage = (message: string) => {
    sendMessage.mutate(message);
  };

  const handleSelectSuggestion = (suggestion: string) => {
    sendMessage.mutate(suggestion);
  };

  const messages = messagesData?.messages || [];
  const isLoading = sendMessage.isPending;
  const showSuggestions = messages.length <= 1 && !isLoading;

  return (
    <div className="flex flex-col min-h-screen max-w-4xl mx-auto px-4 sm:px-6">
      <Header />
      
      <WelcomeMessage />
      
      <ChatContainer 
        messages={messages} 
        isLoading={isLoading} 
      />
      
      {showSuggestions && (
        <SuggestedQuestions 
          suggestions={SUGGESTED_QUESTIONS} 
          onSelectSuggestion={handleSelectSuggestion} 
        />
      )}
      
      <ChatInput 
        onSendMessage={handleSendMessage} 
        isLoading={isLoading} 
      />
    </div>
  );
}
