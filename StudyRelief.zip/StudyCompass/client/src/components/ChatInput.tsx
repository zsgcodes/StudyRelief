import { useState, useRef, FormEvent, ChangeEvent } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SendIcon } from "lucide-react";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

export default function ChatInput({ onSendMessage, isLoading }: ChatInputProps) {
  const [message, setMessage] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    
    if (!message.trim() || isLoading) return;
    
    onSendMessage(message);
    setMessage("");
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  const handleInput = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = "auto";
    textarea.style.height = `${textarea.scrollHeight}px`;
  };

  return (
    <div className="border-t border-neutral-light py-4">
      <form onSubmit={handleSubmit} className="flex items-end gap-2">
        <div className="flex-grow relative">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={handleInput}
            rows={2}
            className="w-full px-4 py-3 border border-neutral-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
            placeholder="Ask about educational stress, study techniques, or academic wellness..."
            disabled={isLoading}
          />
        </div>
        <Button
          type="submit"
          className="bg-primary hover:bg-primary-dark text-white p-3 rounded-full transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed h-12 w-12 flex items-center justify-center"
          disabled={!message.trim() || isLoading}
        >
          <SendIcon className="h-5 w-5" />
        </Button>
      </form>
      
      <div className="mt-3 text-xs text-muted-foreground">
        <p>StudyRelief provides general educational guidance only. It is not a substitute for professional therapy or mental health services.</p>
      </div>
    </div>
  );
}
