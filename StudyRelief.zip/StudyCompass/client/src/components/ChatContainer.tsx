import { useEffect, useRef } from "react";
import Message from "./Message";
import TypingIndicator from "./TypingIndicator";
import { type Message as MessageType } from "@/lib/types";

interface ChatContainerProps {
  messages: MessageType[];
  isLoading: boolean;
}

export default function ChatContainer({ messages, isLoading }: ChatContainerProps) {
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  return (
    <div 
      ref={chatContainerRef}
      className="chat-container flex flex-col space-y-4 py-4 h-[calc(100vh-180px)] overflow-y-auto scroll-smooth"
    >
      {messages.map((message) => (
        <Message key={message.id} message={message} />
      ))}
      
      {isLoading && <TypingIndicator />}
    </div>
  );
}
