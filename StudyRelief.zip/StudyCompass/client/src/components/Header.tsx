import { BrainCog } from "lucide-react";

export default function Header() {
  return (
    <header className="py-4 border-b border-neutral-light">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <BrainCog className="text-primary mr-2 h-5 w-5" />
          <h1 className="text-xl font-semibold">StudyRelief</h1>
        </div>
        <span className="text-sm text-muted-foreground">Educational Therapy Assistant</span>
      </div>
    </header>
  );
}
