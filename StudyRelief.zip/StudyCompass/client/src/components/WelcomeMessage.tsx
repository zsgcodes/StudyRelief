export default function WelcomeMessage() {
  return (
    <div className="my-4 p-4 bg-white rounded-lg shadow-sm border border-neutral-light">
      <h2 className="font-medium text-lg mb-2">Welcome to StudyRelief</h2>
      <p className="text-sm text-neutral-dark mb-3">
        I'm here to help with educational stress, study techniques, and academic wellness. 
        Ask me anything related to your educational journey!
      </p>
      <div className="text-xs text-muted-foreground">
        <p className="mb-1">✓ Get advice on managing academic stress</p>
        <p className="mb-1">✓ Learn effective study techniques</p>
        <p className="mb-1">✓ Find balance between education and mental wellness</p>
      </div>
    </div>
  );
}
