interface SuggestedQuestionsProps {
  suggestions: string[];
  onSelectSuggestion: (suggestion: string) => void;
}

export default function SuggestedQuestions({ 
  suggestions, 
  onSelectSuggestion 
}: SuggestedQuestionsProps) {
  return (
    <div className="mb-4">
      <h3 className="text-sm font-medium mb-2">Try asking about:</h3>
      <div className="flex flex-wrap gap-2">
        {suggestions.map((suggestion, index) => (
          <button
            key={index}
            className="text-xs bg-white border border-neutral-light rounded-full px-3 py-1 hover:bg-neutral-light transition-colors"
            onClick={() => onSelectSuggestion(suggestion)}
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
}
