export default function TypingIndicator() {
  return (
    <div className="message-ai p-3">
      <div className="typing-indicator flex items-center">
        <span className="h-2 w-2 bg-primary rounded-full"></span>
        <span className="h-2 w-2 bg-primary rounded-full"></span>
        <span className="h-2 w-2 bg-primary rounded-full"></span>
      </div>
    </div>
  );
}
