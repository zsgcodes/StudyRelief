import { type Message as MessageType } from "@/lib/types";
import { cn } from "@/lib/utils";

interface MessageProps {
  message: MessageType;
}

export default function Message({ message }: MessageProps) {
  return (
    <div
      className={cn(
        "p-3 text-sm",
        message.isUser
          ? "message-user max-w-[80%] self-end bg-primary text-white rounded-[18px_18px_4px_18px]"
          : "message-ai max-w-[80%] self-start bg-white border border-neutral-light rounded-[18px_18px_18px_4px]"
      )}
    >
      <div className="whitespace-pre-wrap">{message.content}</div>
    </div>
  );
}
