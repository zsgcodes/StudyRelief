export interface Message {
  id: number;
  content: string;
  isUser: boolean;
  createdAt: Date;
  conversationId: string;
}

export interface ChatResponse {
  message: Message;
  conversationId: string;
}

export interface ConversationResponse {
  conversationId: string;
}

export interface MessagesResponse {
  messages: Message[];
}
